<?php
/**
 * 使用说明：
 * (1) 此程序是用来收集memcached status的数据
 * (2) 正确运行此程序需要你的环境已经安装memcached module, 你可以参考http://code.google.com/p/memcached/
 * (3) 您需要配置两个参数： $Mhost 和 $Mport 代表memcached 所在服务器的ip和端口。
 * (4) 此PHP文件名可以随意修改,但必须能让OSA监控精灵所在服务器能正常访问到。
 * (5) 配置好参数后,请将此页面的完整URL作为状态页URL输入对应的 memcache 监控项目表单。
 **/

 
//此处修改为您想要监控的memcache主机地址
$Mhost = '127.0.0.1';

//此处根据您的实际情况进行填写端口地址。
$Mport = 11211;

 
$memcache_obj = new Memcache;

$retvalInfo = $memcache_obj->connect($Mhost, $Mport);

if (!$retvalInfo) die('Could not connect memcached.');

$status = $memcache_obj->getExtendedStats();

$memcache_obj->close();

header('Content-Type: text/plain; charset=UTF-8');

if (empty($status) || !is_array($status)) {
	echo 'Connect to memcached error.';
	exit;
}

echo json_encode($status[$Mhost.':'.$Mport]);

