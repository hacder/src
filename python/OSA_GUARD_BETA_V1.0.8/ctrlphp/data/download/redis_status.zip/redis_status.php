<?php
/**
 * 使用说明：
 * (1) 此程序是用来收集redis status的数据
 * (2) 正确运行此程序需要你的环境已经安装php-redis module, 你可以参考http://code.google.com/p/php-redis
 * (3) 你需要配置两个参数： $Rhost 和 $Rport 代表redis所在服务器的主机和端口
 * (4) 此PHP文件名可以随意修改,但必须能让OSA监控精灵所在服务器能正常访问到。
 * (5) 配置好参数后,请将此页面的完整URL作为状态页URL,输入对应的 redis 监控项目表单。
 *
 **/

 // 此处配置主机参数
$Rhost='192.168.0.146';

//此处配置端口参数
$Rport='6379';  

$redis = new Redis();
$redis->connect($Rhost,$Rport);

$status = $redis->info();

$redis->close();

if (empty($status) || !is_array($status)) {
	echo 'Connect to redis error.';
	exit;
}

echo json_encode($status);

